DTHC Club Manager V3
Open index.html in Safari/Chrome.

IMPORTANT: This is a working local prototype. Data is saved in the browser on the device.
For true multi-device access, the next step is connecting this UI to a cloud database and adding club-admin login.

The navigation uses normal HTML links (#dashboard, #players, #numbers, #orders), so the tabs work even in restrictive previews. For full add/edit/save functionality, open index.html in a normal browser.
